package egovframework.example.sample.service;

public class DeptVO {
	//화면에서 전송누르면 여기에 담기게끔 함 근데 프라이버트 처리하면 안담겨짐 그래서 getset설정함
	private String deptno;
	private String dname;
	private String loc;
	
	public String getDeptno() {
		return deptno;
	}
	public void setDeptno(String deptno) {
		this.deptno = deptno;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}

}
